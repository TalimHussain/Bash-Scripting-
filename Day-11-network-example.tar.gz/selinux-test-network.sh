#!/bin/bash
for i in 192.168.225.53 192.168.225.70
do
a=`ssh root@"$i" getenforce 2> /dev/null`
if [ "$a" = "Enforcing" ]
then
	echo  "you are PASSED"
	echo  "$i is having Enforcing mode"
else
	echo "$i is down"
fi
done
