#!/usr/bin/expect 
spawn scp  -r  /etc    root@192.168.225.53:/tmp 
expect "password:"
send "redhat\r"
interact
