#!/usr/bin/expect 
spawn ssh 192.168.225.53 "df  -h"
expect "assword:"
send "redhat\r"
interact
