#!/bin/bash
for i in 192.168.225.53  192.168.225.70
do
ping -c 2 $i >>  /dev/null 
if [ $? -eq  0 ]
then
echo  "$i is up"
echo  "run these command on $i node"
ssh root@192.168.225.53 << EOF
yum install nfs*  -y  
systemctl start nfs-server
systemctl enable nfs-server
mkdir /cloud
touch  /cloud/abc{1..5}
echo  "/cloud    *(rw)"  >>  /etc/exports
exportfs
EOF
echo  "all task has been completed"
else
	echo  "$i is down"

fi
done

