#!/bin/bash
sshpass -f /root/password ssh root@192.168.225.53 << EOF
mkdir /dear
touch  /dear/abc
EOF
