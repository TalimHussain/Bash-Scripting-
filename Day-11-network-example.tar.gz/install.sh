#!/bin/bash
ssh root@192.168.225.53 << EOF
yum install nfs*  -y  
systemctl start nfs-server
systemctl enable nfs-server
mkdir /cloud
touch  /cloud/abc{1..5}
echo  "/cloud    *(rw)"  >>  /etc/exports
exportfs
EOF
