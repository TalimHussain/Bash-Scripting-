#!/bin/bash
a=`ssh root@192.168.225.53 getenforce`
if [ "$a" = "Enforcing" ]
then
	echo  "you are PASSED"
else
	echo  "change your selinux mode"
fi
