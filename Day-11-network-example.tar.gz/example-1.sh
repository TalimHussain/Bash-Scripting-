#!/bin/bash
ssh root@192.168.225.53 'mkdir /redhat ; touch /redhat/abc'
ssh root@192.168.225.53 systemctl status crond 
ssh root@192.168.225.53 useradd rohit
