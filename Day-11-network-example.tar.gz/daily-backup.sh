#!/bin/bash
ping  -c 2 192.168.225.53 >> /dev/null 
if [ $? -eq 0 ]
then
echo	"192.168.225.53 is up"
	 rsync  -av  root@192.168.225.53:/home   /backup 
	 echo "backup completed"  | mail  -s  "$i backup done" root@localhost
else
	echo  "$i is down"
	echo "$i is down backup failed "  | mail  -s  "$i backup failed" root@localhost
fi
