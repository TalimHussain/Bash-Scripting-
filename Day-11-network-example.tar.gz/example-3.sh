#!/bin/bash
sshpass -f /root/password ssh root@192.168.225.53 << EOF
mkdir /network
touch  /network/abc
EOF
sshpass -f /root/password ssh root@192.168.225.197 << EOF
mkdir /network
touch  /network/abc
EOF
