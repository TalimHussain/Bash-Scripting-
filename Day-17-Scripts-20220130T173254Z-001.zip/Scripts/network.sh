#!/bin/bash
# By this script we configure the Networking in our system.

echo      -e  "\033[01;31m this is your old ip  \033[m"
ifconfig   ens33 |  grep -w inet 

z=`nmcli connection show    |  grep ens33 | awk  '{print $1}'`
if [ -z = $z  ] ; then
echo  " Connection Allready Exits"
else
nmcli connection  delete  $z
echo "Old Connection deleted because "
echo "We have a single  'ens33'  InterFace "
fi 
echo  "   " 
echo "we have a 2 option to assign IP's "
echo  "1st one is Manual and 2nd one is by DHCP"
echo " "
read -p "Select any one ( manual or dhcp ) for create connection name = " a
echo " "

if [ $a = "manual" ] ; then 
	echo "You want to configure IP with "$a" Method"
	read -p "Give the IP and Subnet Mask what you want = " d
	nmcli connection add con-name "$a" ifname ens33 type ethernet autoconnect yes ip4 "$d"               > /dev/null
	echo  "$a" "connection created" 
elif [ $a = "dhcp" ] ; then	
	echo "You want to configure IP with "$a" Method"
	nmcli connection add con-name "$a" ifname ens33 type ethernet autoconnect yes                >> /dev/null
	echo  "$a" "connection created"
else
	echo  -e "Please Only any one method \033[01;31m manual or dns \033[m"	
fi
	nmcli connection up $a   >>  /dev/null
if  [ $? = 0 ] ; then 
	echo	"This is your IP"
	ifconfig   ens33 |  grep -w inet 
	echo " "
	echo -e  "\033[01;31m Netwroking is Successfully Created \033[m"
else
        echo -e  "\033[01;31m Some issue to creating Network  \033[m"
        echo -e  "\033[01;31m Run again same script and read carefully all outputs   \033[m"
fi

