#!/bin/bash

# By this script we configure yum server...

echo 	-e  "\033[01;34m   Configruation the YUM Server   \033[0m"
read -p "Give any Name for repo file = " a
echo " "    	 # Only For Smart output
echo "You have a yum packages so please assign your Location where stored packages "
echo "If you have not Package so pls Press blanck Blank Enter" 
echo " "
read -p "Give the Path where stored your YUM Packages = " b

if [ -z $b ] ; then 
	echo "you press the Blank Enter"
	echo "Now it is use by defaults path"
	echo " "  # Only For Smart output
	c=`echo "http://content.example.com/rhel8.0/x86_64/dvd/AppStream"`
	echo "$c"
	echo " "  # Only For Smart output
fi

echo "[server] "   	  >> /etc/yum.repos.d/$a.repo
echo "name = Pckages"     >> /etc/yum.repos.d/$a.repo

if [ -z $c ] ; then 
	echo "baseurl = file://"$b" " 	  	  >> /etc/yum.repos.d/$a.repo
else	
	echo "baseurl = "$c"  "	  >> /etc/yum.repos.d/$a.repo
	fi
echo "enabled = 1"  	  >> /etc/yum.repos.d/$a.repo
echo "gpgcheck = 0"	  >> /etc/yum.repos.d/$a.repo
yum clean all 
yum repolist  | grep server 
if [ $? = 0 ] ; then 
	echo -e  "\033[01;31m your 'YUM' is SuccessFully Created \033[0m "
else
	echo -e  "\033[01;31m your 'YUM' is'nt SuccessFully Created \033[0m "
	echo " Please TRY Again"
fi
