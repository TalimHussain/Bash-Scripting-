#!/bin/bash
ssh-keygen   <<EOF



EOF
ssh-copy-id -i /home/kiosk/.ssh/id_rsa.pub  root@serverb.lab.example.com  <<EOF
yes
redhat
EOF
ssh root@serverb.lab.example.com  fdisk /dev/vdb <<EOF
n
p
1

+500M
w
EOF
ssh root@serverb.lab.example.com partprobe /dev/vdb
ssh root@serverb.lab.example.com vgcreate vol0 /dev/vdb1
ssh root@serverb.lab.example.com lvcreate -L 400M -n my_vol vol0
ssh root@serverb.lab.example.com  mkfs.ext4 /dev/vol0/my_vol
ssh root@serverb.lab.example.com  mkdir /data
ssh root@serverb.lab.example.com "echo "/dev/vol0/my_vol /data ext4 defaults 0 0" >> /etc/fstab"
ssh root@serverb.lab.example.com  mount -a
ssh root@serverb.lab.example.com  df -h
ssh root@serverb.lab.example.com  systemctl set-default multi-user.target
ssh root@serverb.lab.example.com  systemctl isolate multi-user.target
ssh root@serverb.lab.example.com  yum install tuned   -y 
ssh root@serverb.lab.example.com  tuned-adm profile virtual-host
ssh root@serverb.lab.example.com  "echo > /root/.ssh/authorized_keys "



ssh-keygen   <<EOF



EOF
ssh-copy-id -i /home/kiosk/.ssh/id_rsa.pub  root@servera.lab.example.com  <<EOF
yes
redhat
EOF
ssh root@servera.lab.example.com  systemctl set-default multi-user.target
ssh root@servera.lab.example.com  systemctl isolate multi-user.target
ssh root@servera.lab.example.com  yum install  http*   -y 
ssh root@servera.lab.example.com  systemctl  start httpd
ssh root@servera.lab.example.com  systemctl  enable httpd
ssh root@servera.lab.example.com  echo "changing the apache portnumber"
ssh root@servera.lab.example.com  'sed -i "45a Listen 8089"  /etc/httpd/conf/httpd.conf'
ssh root@servera.lab.example.com  "echo > /root/.ssh/authorized_keys "
