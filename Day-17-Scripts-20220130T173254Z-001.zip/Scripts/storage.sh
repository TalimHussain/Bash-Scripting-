#!/bin/bash 
fdisk /dev/vdb    <<EOF   
n
p
1

+1G
w
EOF
partprobe /dev/vdb 
lsblk | grep vdb1
if [ $? = 0 ] ; then 
pvcreate  /dev/vdb1
else 
        echo   -e  "\033[31;1m Your Partition Did't find  \033[m "
        echo   -e  "\033[31;1m Please try again  \033[m "
        exit
fi 

read -p "Give a VGName asper your Requirment: " a
vgcreate $a  /dev/vdb1 
read -p "Now Give a LVM Name asper your Requirment: " b 
read -p "Enter The Size for LVM: " c
lvcreate  -L  $c -n $b  /dev/$a
read -p "Enter The FileSystem name: " i
mkfs.$i  /dev/$a/$b
read -p "Give a Directory name for Mounting Point: " d
mkdir $d
mount /dev/$a/$b  $d
df -Th | grep $d
if [ $? = 0 ] ; then 
	echo "/dev/$a/$b    $d  $i defaults 0 0"    >> /etc/fstab
fi
mount -a 
	if [ $? = 0 ] ;	then  
echo " "
echo   -e  "\033[31;1m ##### Your LVM is Successfuly Created ##### \033[m "
	else 
		echo   -e  "\033[31;1m Please Try Again \033[m "
	fi 

