funck () {
read -p "give student machine ip : " i
#echo
echo -e "\033[34;01m "Testing of Question number 1" \033[0m"
#echo 
a=`ssh root@172.25.4.11 yum repolist | tail -1 | awk '{print $2}'` >> /dev/null
if [ $a = 0 ]
then
echo -e "\033[31m "Worng  Answer for yum" \033[0m"
else
echo -e  "\033[32m "good  Answer for yum" \033[0m"
fi

}

funck

#echo
echo -e "\033[34;01m "Testing of Question number 2" \033[0m"
#echo 
selinux () {
a=`ssh root@172.25.4.11 getenforce`
if [ $a = "Enforcing" ]
then
echo -e "\033[32m "successfully configured selinux" \033[0m"
else
echo -e "\033[31m "selinux not configured by user" \033[0m"
fi

}
selinux 

#echo
echo -e "\033[34;01m "Testing of Question number 3" \033[0m"
#echo 
lvsresize () {
a=`ssh root@server4 lvs | grep my_vol |awk  '{print $1,$4}' | cut -d' ' -f2`
if [ $a = "120.00m" ]
then
echo -e "\033[32m "successfully done resize lvm = Ans $a " \033[0m"
else
echo -e "\033[31m "not done properly lvm resize question = wrong Ans $a " \033[0m"
fi
}
lvsresize

#echo
echo -e "\033[34;01m "Testing of Question number 4 " \033[0m"
#echo 
user () {
a=`ssh root@server4 groups harry > user`
b=`ssh root@server4 groups natasha >> user`
c=`ssh root@server4 groups sarah >> user`
d=`ssh root@server4 getent passwd  | egrep -i 'harry|natasha|sarah' | awk -F: '{print $1,$7}' OFS="=" >> user`
a=`cat user`
echo -e "\033[32m "user info "$a"" \033[0m"
}

user
