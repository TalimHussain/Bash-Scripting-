#!/bin/bash 

clear 
echo
echo  -e "\033[01;34m By This Script We can Make a New LVM \033[0m"
echo

read -p  "Enter the Hard Disk name for creating Partition: " disk
read -p  "Enter the Numeric No. For Partition = " part
read -p  "Enter the size for partiotion +size{K,M,G}: " size
fdisk "$disk"  >> /dev/null  <<EOF   
n
p
$part

$size
w
EOF
partprobe "$disk"
abc=`echo $disk$part  | cut -d/ -f3`
lsblk | grep "$abc"    >> /dev/null
if [ $? = 0 ] ; then
        pvcreate  "$disk""$part"
echo " " # Only for Smart Uotput
else 
        echo   -e  "\033[31;1m Your Partition Did't find  \033[m "
        echo   -e  "\033[31;1m Please try again  \033[m "
        exit
fi 
read -p "Give a VGName asper your Requirment: " vg
echo " " # Only for Smart Uotput
vgcreate $vg  "$disk""$part"
echo " " # Only for Smart Uotput
read -p "Now Give a LVM Name asper your Requirment: " lv
echo " " # Only for Smart Uotput
read -p "Enter The Size for LVM size{K,M,G}: " lvsize
echo " " # Only for Smart Uotput
lvcreate  -L  $lvsize  -n $lv /dev/$vg
 if [ $? = 5 ]
        then
                continue 
                echo " " # Only for Smart Uotput
                echo -e "\033[01;31m Please assign sufficient free space \033[m"
                echo " " # Only for Smart Uotput
		read -p "Enter The Size for LVM size{K,M,G}: " lvsize 
		lvcreate  -L  $lvsize  -n $lv /dev/$vg
                echo " " # Only for Smart Uotput
else 
                echo " " # Only for Smart Uotput
fi
read -p "Enter The FileSystem name: " fs
echo " " # Only for Smart Uotput
mkfs.$fs  /dev/$vg/$lv   >> /dev/null
echo " " # Only for Smart Uotput
read -p "Give a Directory name for Mounting Point: " d
mkdir $d
mount /dev/$vg/$lv $d
df -Th | grep $d
if [ $? = 0 ] ; then 
	echo "/dev/$vg/$lv   $d  $fs defaults 0 0"    >> /etc/fstab
fi
mount -a 
	if [ $? = 0 ] ;	then  
echo " "
echo   -e  "\033[31;1m ##### Your LVM is Successfuly Created ##### \033[m "
	else 
		echo   -e  "\033[31;1m Please Try Again \033[m "
	fi 

