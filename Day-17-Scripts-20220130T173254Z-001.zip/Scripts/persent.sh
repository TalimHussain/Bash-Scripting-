#!/bin/bash 
# 
# If you use this Script so please change your Mounting Point and Size Whatever u want to add Only 
# In case your LVM Size is Crossed 80% Then it is automatically add 200M  in same LVM 
# You can add more size like ( 200M 400M Etc. )  

clear 
abc=`df  -Th | grep -w  /data | awk '{print $6}' | cut -d'%' -f1`
lvmname=`lsblk | grep /data |cut -d'-' -f2 | awk '{print $1}'`
vgname=`lvs  | grep $lvmname | awk '{print $2}'`
vgfreesize=`vgs | grep $vgname | awk '{print $7}' |cut -d'.' -f1`

if [ "$abc" -gt "40" ] ; then 
	echo 
	echo -e "\033[01;31m Your /dev/"$vgname"/"$lvmname" LVM Size is allmost full \033[0m"
	echo 
echo -e "\033[01;34m Your /dev/"$vgname"/"$lvmname" LVM Size is Crossed 80%..  \033[0m"
	echo "Your /dev/"$vgname"/"$lvmname" LVM Size is Crossed 80% so Now we r adding 200M. 
	Thanks..."  | mail -s "LVM Size Report" root@station1.example.com  
	echo 
asdf=`zenity  --title "LVM Size" --text "Do You Want Add Some Size in this /dev/"$vgname"/"$lvmname" Partition ? "   zenity --question`
case "$?" in 

0)
	echo 
	echo  -e "\033[01;31m Now we are adding 200MB in Same Disk \033[0m"
	echo
if [ "$vgfreesize" -gt "200" ] ; then 
	echo	
	echo -e "\033[01;34m We Got a Extra Size in Your Volume Group \033[0m"
	lvresize -L +200M -r /dev/"$vgname"/"$lvmname" >> /dev/null 
if [ $? = 0 ] ; then 
echo -e "\033[01;31m 200MB Size is Successfully Added in your disk \033[0m"
	echo 
fi 
else 
	echo -e "\033[01;31m You Don't have Extra Size in your VG \033[0m"
fi 
#########################################################3
;;
1) 
	echo 
        echo -e "\033[01;34m You Don't want to ADD on Size in /dev/"$vgname"/"$lvmname" \033[0m"
	echo 
        echo -e "\033[01;31m  Your /dev/"$vgname"/"$lvmname" LVM Size is Crossed 80% 
	so please USE this LVM Safelly \033[0m"
	echo 
	;;

esac 
else
        echo    
        echo
echo   -e "\033[01;34m /dev/"$vgname"/"$lvmname" size is = \033[01;31m OK  \033[0m"
fi

