
ssh root@servera.lab.example.com  fdisk /dev/vdb <<EOF
n
p
1

+500M
w
EOF
ssh root@servera.lab.example.com partprobe /dev/vdb
ssh root@servera.lab.example.com vgcreate vol0 /dev/vdb1
ssh root@servera.lab.example.com lvcreate -L 400M -n my_vol vol0
ssh root@servera.lab.example.com  mkfs.ext4 /dev/vol0/my_vol
ssh root@servera.lab.example.com  mkdir /data
ssh root@servera.lab.example.com "echo "/dev/vol0/my_vol /data ext4 defaults 0 0" >> /etc/fstab"
ssh root@servera.lab.example.com  mount -a
ssh root@servera.lab.example.com df -h
ssh root@servera.lab.example.com  systemctl set-default multi-user.target
ssh root@servera.lab.example.com systemctl isolate multi-user.target
ssh root@servera.lab.example.com   yum install  http*   -y 
ssh root@servera.lab.example.com   systemctl  start httpd.service
ssh root@servera.lab.example.com   systemctl  enable httpd.service
ssh root@servera.lab.example.com   echo "Listen 8089"  >>  /etc/httpd/conf/httpd.conf
ssh root@servera.lab.example.com    tuned-adm profile virtual-host 
ssh root@servera.lab.example.com     yum install    sssd    authconfig*  -y 

