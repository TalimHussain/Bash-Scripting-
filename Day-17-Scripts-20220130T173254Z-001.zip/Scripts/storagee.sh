#!/bin/bash 
echo   -e  "\033[34;1m  We have "vda and vdb" Hard Disk \033[m "
read -p  "Select 1 Hard Disk for creating Partition: " z
fdisk /dev/"$z"    <<EOF   
n
p
1

+1G
w
EOF
partprobe /dev/"$z"
lsblk | grep vdb1    >> /dev/null
if [ $? = 0 ] ; then 
echo " " # Only for Smart Uotput
pvcreate  /dev/"$z"1
echo " " # Only for Smart Uotput
else 
        echo   -e  "\033[31;1m Your Partition Did't find  \033[m "
        echo   -e  "\033[31;1m Please try again  \033[m "
        exit
fi 

read -p "Give a VGName asper your Requirment: " a
echo " " # Only for Smart Uotput
vgcreate $a  /dev/"$z"1 
echo " " # Only for Smart Uotput
read -p "Now Give a LVM Name asper your Requirment: " b 
echo " " # Only for Smart Uotput
read -p "Enter The Size for LVM: " c
echo " " # Only for Smart Uotput
lvcreate  -L  $c -n $b  /dev/$a
 if [ $? = 5 ]
        then
                continue 
                echo " " # Only for Smart Uotput
                echo -e "\033[01;31m Please assign sufficient free space \033[m"
                echo " " # Only for Smart Uotput
		read -p "Enter The Size for LVM: " c
		lvcreate  -L  $c -n $b  /dev/$a
                echo " " # Only for Smart Uotput
else 
                echo " " # Only for Smart Uotput
        fi
read -p "Enter The FileSystem name: " i
echo " " # Only for Smart Uotput
mkfs.$i  /dev/$a/$b   >> /dev/null
echo " " # Only for Smart Uotput
read -p "Give a Directory name for Mounting Point: " d
mkdir $d
mount /dev/$a/$b  $d
df -Th | grep $d
if [ $? = 0 ] ; then 
	echo "/dev/$a/$b    $d  $i defaults 0 0"    >> /etc/fstab
fi
mount -a 
	if [ $? = 0 ] ;	then  
echo " "
echo   -e  "\033[31;1m ##### Your LVM is Successfuly Created ##### \033[m "
	else 
		echo   -e  "\033[31;1m Please Try Again \033[m "
	fi 

