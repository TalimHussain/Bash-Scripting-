#!/bin/bash
#
# ./copy_scp.sh /tmp/abc  <tmp <dest_ip>   root <root_password>
set buildsourcefolder  [1index $argv 0]
set destinationpath    [1index $argv 1] 
set ip 		       [1index $argv 2]	 
set user 	       [1index $argv 3]
set password           [1index $argv 4]

if { "$buildsourcefolder" =="" } {
puts "No build source folder specified... so exiting the script.....";
exit
}

if { "$destinationpath" =="" } { 
puts "No destination path  specified...  so exiting the script.....";
exit
}

if { "$ip" =="" } {
puts "No destination ip is  specified...  so exiting the script.....";
exit
}

if { "$user" =="" } {
puts "No user  specified...  so exiting the script.....";
exit
}

if { "$password" =="" } {
puts "No Password  specified...  so exiting the script.....";
exit
}

spawn scp -r  "$buildsourcefolder" "$user"@"$ip":"$destinationpath"
expect  "assword:"
send   "$password"\r"
interact

