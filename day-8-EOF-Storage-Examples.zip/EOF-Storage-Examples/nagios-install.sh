#!/bin/bash
yum install -y httpd httpd-tools php gcc glibc glibc-common gd gd-devel make net-snmp
useradd nagios
groupadd nagcmd
usermod -G nagcmd nagios
usermod -G nagcmd apache
mkdir /root/nagios
cd /root/nagios
wget https://assets.nagios.com/downloads/nagioscore/releases/nagios-4.4.5.tar.gz
wget https://nagios-plugins.org/download/nagios-plugins-2.2.1.tar.gz
tar -xvf nagios-4.4.5.tar.gz
tar -xvf nagios-plugins-2.2.1.tar.gz
cd nagios-4.4.5/
./configure --with-command-group=nagcmd
make all
make install
make install-init
make install-commandmode
make install-config
cat >> /usr/local/nagios/etc/objects/contacts.cfg  << EOF
define contact{
contact_name                    nagiosadmin
use                             generic-contact
alias                           Nagios Admin 
email                           admin@tecmint.com
}
EOF
make install-webconf
echo redhat   | htpasswd  -s  -c  -i /usr/local/nagios/etc/htpasswd.users nagiosadmin
systemctl start httpd.service
cd /root/nagios
cd nagios-plugins-2.2.1/
./configure --with-nagios-user=nagios --with-nagios-group=nagios
make
make install
systemctl enable nagios
systemctl enable httpd
systemctl start nagios.service
systemctl start httpd

