#!/bin/bash
# this script is for samba server creation
# we will share a directory using samba.
a=`rpm -qa samba | cut -d'-' -f1`		
if [ "$a" = "samba" ]
then
   echo  "$a RPM is already installed"
else
   yum install samba*  -y 
   echo "$a package successfully installed" 
fi
read -p  "create a directory using mkdir command: " b 
mkdir  "$b"
touch  "$b"/abc{1..5}
chmod 777 $b
echo "this is my samba testing file"  >  "$b"/abc1
sed -i   "5a hosts allow  = 127. 192.168.0."   /etc/samba/smb.conf
cat >> /etc/samba/smb.conf << EOF 
[publicshare]
comment = this is samba server.
path = $b
public = yes
EOF
systemctl start smb 
systemctl enable smb
pidof smb
if [ $? -eq 0 ]
then
   echo "samba service is running"
else
   systemctl start smb
   systemctl enable smb
fi
echo  "congrats your $b directory is shared using SMB"

