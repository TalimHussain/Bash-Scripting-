#!/bin/bash
read -p  "give you filename for ip testing: " IP  
for i in  `cat $IP`
do
  ping  -c 2 $i  >  /dev/null  
  if [ $?  -eq  0 ]
  then  
     echo "$i is UP" 
     mkdir  /tmp/ping-report-$(date +%B:%Y:%H:%M)
     echo "$i is UP"  >>   /tmp/ping-report-$(date +%B:%Y:%H:%M)/OK-$(date +%d:%H:%M:%B:%Y)
  else
     echo  "$i is down" | tee -a  /tmp/NOTOK-$(date +%d:%H:%M:%B:%Y)
     echo "$i ip is Down" | mail -a /tmp/NOTOK -s "IP Report of $i"  root@localhost 
  fi
done
