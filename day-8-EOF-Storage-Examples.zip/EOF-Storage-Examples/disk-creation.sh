#!/bin/bash  
fdisk /dev/sdb << EOF 
n
p
1

+200M
w
EOF
partprobe /dev/sdb  
mkswap  /dev/sdb1
swapon  /dev/sdb1  
c=`blkid  |grep sdb1   | cut  -d'='   -f2   | cut  -d' ' -f1  | cut -d'"' -f2`	
echo  "UUID="$c"     swap    swap   defaults  0 0"  >>  /etc/fstab
mount -a  
free  -h  

