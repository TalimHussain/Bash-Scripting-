fdisk /dev/sdb <<EOF
n
p
1

+500M
w
EOF
partprobe /dev/sdb
pvcreate /dev/sdb1
vgcreate vol0 /dev/sdb1
lvcreate -L 400M -n my_vol vol0
mkfs.ext4 /dev/vol0/my_vol
mkdir /data
echo "/dev/vol0/my_vol /data ext4 defaults 0 0" >> /etc/fstab
mount -a
df -h
