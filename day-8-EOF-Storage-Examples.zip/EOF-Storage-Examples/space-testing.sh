#!/bin/bash
LASTVALUE=10
mailto="root"
HOSTNAME=$(hostname)
for path in `df -h | grep -vE  'Filesystem|tmpfs'  | awk '{print $5}' | sed 's/%//g'`
do
    if [ $path -ge $LASTVALUE ]
    then
    df  -h | grep  $path%  >>  /tmp/info
    fi
done

VALUE=`cat /tmp/info | wc -l`
if [ $VALUE -ge 1 ]
then
   mail -s  "$HOSTNAME Disk usage is critical"  $mailto  < /tmp/info
fi
