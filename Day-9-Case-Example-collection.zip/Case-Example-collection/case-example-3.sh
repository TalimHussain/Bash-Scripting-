#!/bin/bash
echo  "press 1 to check cpu status"
echo  "press 2 to check memory status"
echo  "press 3 to check uptime status"
echo  "press 4 to check login user report"
read -p  "give any number from 1 to 4 to get reports: " i
case $i in
1)  lscpu 
    date
    cal 
   for i in 1 2 3 4 5
   do
   echo  "numbers are = $i"
   done ;;
2)  free -h ;;
3)  uptime ;;
4)  who ;;
*) echo  "you have given wrong input value use only 1 to 4" ;;
esac
