#!/bin/bash
echo  "press 1 to check cpu CPU Model"
echo  "press 2 to check ip  status"
echo  "press 3 to check uptime status"
echo  "press 4 to check login user report"
PS3="give any number: "
select i in 1 2 3
do
case $i in
1) echo  "you have press 1 to check cpu status"
   lscpu |  grep -i  "model name" ;;
2) echo  "you have press 2 to check uptime status"
   ifconfig | grep -w inet  |  head -1 | awk '{print $2}';;
3) echo  "you have press 3 to exit from the program"
   break ;;
*) echo  "you have given wrong input value use only 1 to 3" ;;
esac
done
