#!/bin/bash
trap '' 2            # to stop function of CTRL+C option"
while true
do
clear
echo "===================="
echo "menu ---------------------------"
echo "===================="
echo "Enter 1 to list users"
echo  "Enter 2 to show disk status"
echo  "enter 3 to show cpu status"
echo  "enter q to quit from the program"
echo -e  "\n"
echo  -e "Enter you selection number \c"
read answer
case "$answer" in 
1) echo  "you have press 1"
    who ;;

2) echo  "you have press 2"
    lsblk ;;

3) echo  "you have press 3"
    lscpu;;

q)  echo  "you have press q option to quit from program"
     exit ;;
esac
echo  -e "Enter return to continue \c"
read input
done
