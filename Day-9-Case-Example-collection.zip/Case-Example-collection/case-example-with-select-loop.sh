#!/bin/bash
echo  "press 1 to check cpu status"
echo  "press 2 to check memory status"
echo  "press 3 to check uptime status"
echo  "press 4 to check login user report"
echo  "press 5to exit from the program"
select i in 1 2 3 4 5 
do
case $i in
1)  lscpu ;;
2)  free -h ;;
3)  uptime ;;
4)  who ;;
5) echo "you have 5 to exit from the loop statment"
   break ;;
*) echo  "you have given wrong input value use only 1 to 4" ;;
esac
done
