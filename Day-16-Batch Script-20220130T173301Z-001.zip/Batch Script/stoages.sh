#/!bin/bash

lsblk

#============================= Creating partition ==================================================================

echo -e  "\033[01;31m please enter the disk name for partition: \033[0m"
read diskname
op=`fdisk -l $diskname`
echo -e "\033[01;41m current partitions are \n $op \033[0m"

echo -e  "\033[01;31m please enter the size for partiotion: \033[0m"
read size
fdisk $diskname << eof
n
p


$size
w
eof

partprobe
op=`fdisk -l $diskname`
echo -e "\033[04;41m Updated partions are \n $op \033[0m"



echo -e "\033[01;32m $size of partition is created, Please check the below options for next step** \033[0m"


#echo  -e "\033[01;33m Please enter file system name  to format:\033[0m "
#read filesystem
#==================================== PV CREATION ======================================================================
echo  -e "\033[01;33m Please enter partition name  to create PV:\033[0m "
read partname

pvcreating () {
pvcreate $partname

if [ $? -eq 0 ]
then
pvs

echo "PV created by $partname"
else
echo " please enter correct partion name"
echo  -e "\033[01;33m Please enter partition name  to create PV:\033[0m "
read partname
pvcreating
fi
}
pvcreating

#if [ $? -gt 0 ]
#then
#echo " please enter correct partion name"
#echo  -e "\033[01;33m Please enter partition name  to create PV:\033[0m "
#read partname
#pvcreating
#fi

#============================= VG Creation ============================================================================
vgcreating () {
echo -e "\033[01;32m please enter your vgname \033[0m"
read vgname

#echo -e "\033[01;32m please enter pvdisk partiotion name \033[0m"
#read pvdisk
vgcreate $vgname $partname
#else
#echo " Please try again"
#exit
#fi
if [ $? -eq 0 ]
then
echo "VG has been created successfully"
echo -e "\033[01;42m vg name is  $vgname \033[0m"
vgs
else
vgcreating
fi
}
vgcreating
#========================= LV CREATION ========================================================================================
echo -e "\033[01;32m please enter your LV name: \033[0m"
read lvname

echo -e "\033[01;32m please enter your LV +size{K,M,G}: \033[0m"
read lvsize
lvcreate -L $lvsize -n $lvname /dev/$vgname

if [ $? -eq 0 ]
then

echo "* LV has been created successfully LV="/dev/$vgname/$lvname" **"
lvscan
lvs
else
echo -e  "\033[01;42m There is some issue in creating LVM. Would you like to Rollback or Exit \033[0m"
#=================================ROLLBACK WHEN LVM CREATION FAILED ====================================================================
PS3="Select 1 for Rollback and 2 for Quit:  "
select i in Rollback Quit
do
#functions () {
case $i in
[rR]ollback)
#$lvremove $LV
#$lvs


vgremove $vgname
vgs
pvremove $partname
pvs
fdisk /dev/sdc << eof
d

w
eof

partprobe
op=`fdisk -l $diskname`

echo -e  "\033[01;32m rollback has been completed successfully \n $op\033[0m"
#echo -e  "\033[01;32m Rollback failed due to some reason. Please veruify accordingly.\033[0m"

exit
;;
*)
exit ;;
esac
done
fi
#================= FORMATING LVM ========================================


echo  -e "\033[01;33m Please enter file system name  to format:\033[0m "
read filesystem
mkfs.$filesystem /dev/$vgname/$lvname

echo -e "\033[01;34m **partition has been formated successfully* \033[0m"

#===========DIRECTORY CREATION=====================================================

directory () {
echo -e "\033[01;35m please enter the required dir name:\033[0m"
read dir
mkdir $dir
if [ $? -eq 0 ]
then
echo -e "\033[01;35m $dir created successfully\033[0m"
else
directory
fi

}
directory

#====================== Permanent mounting ==================================================

#if [ $? -eq 0 ]
#then
#echo -e "\033[01;35m $dir created successfully\033[0m"
#else
#directory
#fi
if [ $? -eq 0 ]
then
echo "/dev/$vgname/$lvname   $dir     $filesystem defaults       0       0"      >> /etc/fstab
fi
if [ $? -eq 0 ]
then
mount -a
fi
if [ $? -eq 0 ]
then
echo -e "\033[01;41m  Mounting has been done successfully. LVM has been created successfully  \033[0m"
lvs
#==================================== ROLLBACK IF Anything Wrong in Mounting point =========================================
else
echo -e "\033[01;41m Something went wrong. Follow the below instuctions \033[0m"
#echo -e "Please enter YES or NO further: "
#read i
PS3="Please select 1 for Rollback and select 2 for Quit: "
select i in Rollback Quit
do
#functions () {
case $i in
Rollback)
umount $dir
#if [ $? -eq 0 ]
#then
cat /etc/fstab
#echo "successfully unmounted"
#else
#echo " failed to umount"
echo -e "\033[01;42m would you like to remove the last line of Fstab \033[0m"
echo
echo -e "\033[01;43m Type YES to Continue and NO to Quit \033[0m"
read inputs
if [ $inputs = "YES" ]
then
sed -i '$d' /etc/fstab
cat /etc/fstab
echo "last line has been deleted successfully"

lvremove /dev/$vgname/$lvname
lvs
#Vgremove

vgremove $vgname
vgs
pvremove $partname
pvs
fdisk $diskname << eof
d

w
eof


partprobe
op=`fdisk -l $diskname`

echo -e  "\033[01;32m $op \033[0m"
echo
echo

echo -e  "\033[01;32m rollback has been completed successfully\033[0m"
else
echo "\033[01;32m rollback FAILED\033[0m"
fi
if [ $inputs = "NO" ]
then
echo " Quiting script"
exit
fi

;;
Quit) break ;;
esac
done


#if [ $? -eq 0 ]
#then

#lvremove /dev/$vgname/$lvname
#lvs
#Vgremove

#vgremove $vgname
#vgs
#pvremove $partname
#pvs
#fdisk $diskname << eof
#d
#
#w
#eof
#fi

#partprobe
#fdisk -l $diskname
#echo -e  "\033[01;32m rollback has been completed successfully\033[0m"

fi
echo "* CONGRATS *"

#+++++++++++++++++++++++++++++++++ DONE +++++++++++++++++++++++++++++++++++++