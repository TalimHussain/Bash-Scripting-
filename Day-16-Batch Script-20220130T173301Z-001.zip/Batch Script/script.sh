#!/bin/bash
# script modify or not

rm -f /tmp/service.txt
file=/tmp/service.txt
from=`hostname -i`

DIRs=(/root/scripts) 
DIR1=(/opt/scripts)
for dir in ${DIRs[@]}  ${DIR1[@]}
do
        find $dir -mtime -1 -type f >> $file
done

if [ -s $file ]; then
cat $file | mail -s " Below script has been modified yesterday  on  $from" pravej.alam@aajtak.com tarun.sood@aajtak.com
else
        echo "SCRIPT NOT MODIFIED ON $from"
fi


#cron modify or not .
rm -f /tmp/cron-update.txt
file1=/tmp/cron-update.txt
find /var/spool/cron -mtime -1 -type f >> $file1
if [ -s $file1 ]; then
mail -s "cron has been modified  yesterday   $from"  pravej.alam@aajtak.com tarun.sood@aajtak.com < /dev/null

fi