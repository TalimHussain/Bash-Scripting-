#!/bin/bash
hello_world () {
echo 'hello, world'
}
hello_world
