#!/bin/bash
name=krishna
