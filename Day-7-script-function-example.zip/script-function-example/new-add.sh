#!/bin/bash
read -p  "give any first number: " a
read -p  "give any second number: " b
add () {
       sum=`expr $a + $b`
       echo  "sum of $a and $b is = $sum"
       }
minus () {
         xyz=`expr $a - $b`
         echo  "minus from $a and $b is = $xyz"
        } 
echo  "output of add function is"
minus
echo  "output of minus function is"
add
