#!/bin/bash
read  -p "give any service name to check status: " SERVICE
if pgrep -x "$SERVICE" >/dev/null
then
echo "$SERVICE is running"
else
echo "$SERVICE stopped"
fi
