#!/bin/bash
read -p  "what is your name please: "
echo  "your name is = $a"
