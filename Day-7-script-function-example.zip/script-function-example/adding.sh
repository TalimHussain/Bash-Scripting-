#!/bin/bash
hello () {
        echo  " this is my first example of function"
        systemctl  restart crond  
        systemctl  enable crond 
        a=10
        b=5
        sum=`expr $a + $b`
        echo  "sum of $a and $b is = $sum"
        }
echo -e "***************************** \n\n"
for i in {1..5}
do
echo  "numbers are = $i"
done
echo -e  "****************  output of hello function is ****** \n\n"
hello
