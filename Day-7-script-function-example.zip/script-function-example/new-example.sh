#!/bin/bash
read  -p  "give service name to restart it: " a
service () {
         systemctl start $a
         systemctl enable $a
        }
pidof $a
if [ $? = 0 ]
then
    echo  "$a service is already running"
else
    echo  "again start the service"
    service 
fi
