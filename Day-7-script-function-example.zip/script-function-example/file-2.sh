#!/bin/bash
source  /root/file-1.sh 
echo  "you name is $name"
