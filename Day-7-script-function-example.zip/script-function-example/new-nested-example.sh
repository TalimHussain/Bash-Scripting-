#!/bin/bash  
read  -p  "give any first service: " a
read  -p  "give any second service: " b
service () { 
        	systemctl start $a
        	systemctl start $b
         }
enabled () {
       		 systemctl enable $a
        	 systemctl enable $b
           }
action () {
pidof $a
pidof $b
if [ $? = 0 ]
then
    echo  "$a service is already running"
    echo  "$b service is already running"
else
    echo  "again start the service"
    service 
    enabled
fi
}
action 
