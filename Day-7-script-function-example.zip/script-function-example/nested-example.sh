#!/bin/bash  
first () { 
         a=10
         b=5
         abc=`expr $a + $b`
         echo $abc 
         second

         }
second () {
          xyz=`expr $a - $b`
          echo  "$xyz"
          }
first
