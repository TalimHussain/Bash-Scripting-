#!/bin/bash
read -p "Enter your username: " myname
read -sp "Enter your password: " mypassword
echo -e  "\nYour username is $myname and Password is $mypassword"
