#!/bin/bash
xyz=`cat $1 | wc -l`
file () {
echo The file $1 has $xyz lines in it.
}
file
