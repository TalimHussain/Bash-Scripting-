#!/bin/bash 

	clear 
	echo
	echo  -e "\033[01;34m By This Script We can Make a New LVM \033[0m"
	echo
	sleep 2
info=`zenity --info --title "Disk Creation" --text "Note Read to carefully all Steps"`
checkdisk=`lsblk  | grep disk | cut  -d' '  -f1`
partcheck=`lsblk   | grep   part | cut  -d' '  -f1`

	echo   -e  "\033[34;1m  We have \033[01;32m "$checkdisk" \033[m Hard Disk \033[m \n "
	echo   -e  "\033[34;1m  We Have allready Created \033[01;32m "$partcheck" \033[m Partitions \033[m "
	echo   -e  "\033[34;1m  So Please create New No. Partitions \033[m \n"

read -p  "Enter any 1 Hard Disk name for creating Partition: " disk
read -p  "Enter the Numeric No. For Partition = " part
read -p  "Enter the size for partiotion Size{K,M,G}: " size
fdisk "/dev/$disk"  >> /dev/null  <<EOF   
n
p
$part

+$size
w
EOF
	partprobe "/dev/$disk"
abc=`echo /dev/$disk$part  | cut -d/ -f3`
	lsblk | grep "$abc"    >> /dev/null
if [ $? = 0 ] ; then
        echo   -e  "\033[32;01m Your "$disk""$part" Partition is Successfully Created  \033[m "
	echo " " # Only for Smart Uotput
else 
        echo   -e  "\033[31;1m Your Partition Did't find  \033[m "
        echo   -e  "\033[31;1m Please try again  \033[m "
        exit
fi 
	
        echo   -e  "\033[31;1m Do you Want Create LVM By Same Script?  \033[m "
        echo   -e  "\033[31;1m IF you want then Click on "YES" Button
		 else Click on "No" Button  \033[m "
	sleep 4
	echo 
########################  CASE Statement ##############################
zenty=`zenity  --question  --text "Do You Want Create LVM By Same Script
					Yes or No?"`
case $? in 
0)
        echo   -e  "\033[31;1m Yes You Want Create LVM By Same Script  \033[m  \n"
        pvcreate  /dev/"$disk""$part"   	>> /dev/null
read -p "Give a VGName asper your Requirment: " vg
	vgcreate $vg  /dev/"$disk""$part"	>> /dev/null
read -p "Now Give a LVM Name asper your Requirment: " lv
read -p "Enter The Size for LVM size{K,M,G}: " lvsize   
	lvcreate  -L  $lvsize  -n $lv /dev/$vg	>> /dev/null
if [ $? -gt 0 ] ; then 
                echo " " # Only for Smart Uotput
                echo -e "\033[01;31m Please assign sufficient free space \033[m"
                echo " " # Only for Smart Uotput
		read -p "Enter The Size for LVM size{K,M,G}: " lvsize 
		lvcreate  -L  $lvsize  -n $lv /dev/$vg	>> /dev/null
                echo " " # Only for Smart Uotput
else 
                echo " " # Only for Smart Uotput
fi
read -p "Enter The FileSystem name: " fs
	mkfs.$fs  /dev/$vg/$lv   >> /dev/null
read -p "Give a Directory name for Mounting Point: " d
	mkdir $d
	mount /dev/$vg/$lv $d  
	df -Th | grep $d	>> /dev/null
if [ $? = 0 ] ; then 
	echo "/dev/$vg/$lv   $d  $fs defaults 0 0"    >> /etc/fstab
fi
	mount -a 
if [ $? = 0 ] ;	then  
	echo " "
	echo   -e  "\033[31;1m ##### Your LVM is Successfuly Created ##### \033[m "
else 
		echo   -e  "\033[31;1m Please Try Again \033[m "
fi 
	;;
1)
	echo	
        echo   -e  "\033[31;1m You don't Want to Create LVM By Same Script  \033[m \n "
        echo   -e  "\033[32;01m \t Your "$disk""$part" Partition is Successfully Created
	and Use it as per your requirement \033[m "

	;;
	 
esac
	
        echo   -e  "\033[31;1m  \n\t Thanks For Using this Script  \033[m "
