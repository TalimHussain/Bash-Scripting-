#!/bin/bash
mysql -u root -predhat <<MY_QUERY
USE mysql;
SHOW tables  ;    
SELECT user,host  from  user;
create user neeraj@localhost identified by  'redhat';
MY_QUERY
