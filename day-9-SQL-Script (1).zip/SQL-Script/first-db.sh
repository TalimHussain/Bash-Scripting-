#!/bin/bash
mysql -u root -predhat <<MY_QUERY
USE mysql;
SHOW tables  ;    
SELECT user,host  from  user;
MY_QUERY
