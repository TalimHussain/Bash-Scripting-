#!/bin/bash  
read -p  "which user name you want to find out in MARIADB SERVER: " i
a=`mysql  -u root  -predhat  -e  'use mysql; show tables;select user from user;' | grep $i` 
if [ "$a" = "$i" ]
then
   echo "$i user is alreay exit in database server"
else

   echo "we are going to create it"
   mysql  -u root  -predhat  -e  "use mysql; create user "$i"@localhost identified by 'redhat';"
fi
